import { apiClient } from './apiClient';

export const authService = {
  login: async (email, password) => {
    const users = await apiClient.get(`/users?email=${email}&password=${password}`);
    if (users.length > 0) return users[0];
    throw new Error('Invalid credentials');
  },

  register: async (userData) => {
    const newUser = {
      name: userData.fullName,
      email: userData.email,
      password: userData.password,
      plan: 'Free',
      bio: ''
    };
    return await apiClient.post('/users', newUser);
  },

  updateProfile: async (id, data) => {
    return await apiClient.patch(`/users/${id}`, data);
  }
};
