import { apiClient } from './apiClient';

export const documentService = {
  getAll: async () => {
    return await apiClient.get('/documents');
  },

  getById: async (id) => {
    return await apiClient.get(`/documents/${id}`);
  },

  create: async (file) => {
    const newDoc = {
      title: file.name,
      type: file.name.split('.').pop().toUpperCase(),
      date: new Date().toISOString().split('T')[0],
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      category: 'Uncategorized'
    };
    return await apiClient.post('/documents', newDoc);
  },

  delete: async (id) => {
    return await apiClient.delete(`/documents/${id}`);
  }
};
